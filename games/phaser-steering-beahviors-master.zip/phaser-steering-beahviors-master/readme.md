Things are shaping up.

- Got some good objects and inheritence going on. No proper implementation of super but this will work for now and is a nice demonstration of the prototypal inheritence.

- Renamed the base object to be more semantic and what the immovable object inherits from.

- Wandering is still in progress, with thte added inheritance I increaded the dubbging rendering, it is close, with the add debugging it should be easy to figure out.

- Once I have all that in a nice place Ill add the build system and make it cleaner experience, not all these separate pages.

-- Current Working Behaviors --
- Seeking
- Flocking
- Object Avoidance
- Wandering
- Pursue
- Flee
- Evade
- Pathing

-- On the Docket --
- Follow
- Leader
- Queuing
- Proximity Aware Pursuit
- Proximity Aware Evade
- Ship Avoidance - need to project spheres not points. or line to line?

-- Things that need doing --
- Arrival/Pursuit/Evading/Fleeing debug rendering
- Initializers and default objects, and undefined checks
- implement more faces functions
- Increase Efficency of loops.
- Build tools
- Bower
- Learn better markdown
