// Planned object to periodically spawn an object
function ObjectSpawn(){

}