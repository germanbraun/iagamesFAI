// Planned factory method for building out objects
function Factory(){

}
